#!/usr/bin/env python
# encoding: utf-8

# IMPORTS
from .api import tokenize
__version__ = "1.0.1"
__all__ = ['tokenize']

